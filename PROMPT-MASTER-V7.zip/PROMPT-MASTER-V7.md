# 🚀 PROMPT DE CONTINUIDADE — MULTITOOL (v7)

**Data deste snapshot: 18/08/2026**
**Cole este arquivo no início de um chat novo. É a fonte da verdade. O usuário é iniciante. Siga à risca.**

**NÃO apague nem recrie do zero tools que já estão READY. Sempre parta deste catálogo. Se for mandar `tools.ts`, mande o arquivo INTEIRO incluindo todas as ready abaixo (incluindo giveaway-picker e os 13 jogos).**

---

## 🎯 OBJETIVO

Site global de tools gratuitas em **INGLÊS**: https://multitoolbox.online
Next.js 14+ App Router + TypeScript + Tailwind. Vercel (app) + Hostinger (só domínio/DNS).
Tudo que der: **100% client-side** (privacidade). AdSense depois.

---

## 🌐 CONTAS / LIVE

| Item | Valor |
|---|---|
| Site | https://multitoolbox.online |
| Hostinger | domínio, renovação AUTO OFF, expira 12/08/2027 ~R$197,99 |
| Email | multitool.com@gmail.com |
| GitHub | multitool-com/multitool (público) — branch master |
| Vercel | multitoolcom-6711 / projeto multitool / Hobby / backup multitool-mu.vercel.app |
| Local | `C:\multitool` (Windows, VS Code) |
| Git | user.name=multitool-com / user.email=multitool.com@gmail.com |
| Deploy | `git add .; git commit -m "..."; git push` (JEITO B — tudo numa linha com `;`) |
| Analytics | G-M03VJPSYZZ em `layout.tsx` (`@next/third-parties/google`) |
| Search Console | domínio verificado. TXT: `google-site-verification=bmPXHsHy6C5LgUU38FFAS05LSiCamLz-AKj6_5aY9AY` — **NÃO REMOVER** |
| PWA | `src/app/manifest.ts` com `display: "browser"` (sem "instalar app") |

---

## 📦 ESTRUTURA

```
src/app/layout.tsx              → <SiteHeader />
src/app/page.tsx                → hero /hero.jpg + 7 atalhos desktop
src/app/manifest.ts             → display: "browser"
src/components/SiteHeader.tsx   → hamburger; fecha ao navegar (usePathname)
src/components/ToolLayout.tsx
src/components/ToolPlaceholder.tsx
src/lib/tools.ts                → catálogo; SEMPRE substituir INTEIRO
public/hero.jpg
public/games/*.jpg              → capas dos jogos (13 capas)
src/app/tools/[cat]/[slug]/page.tsx + [Nome]Client.tsx
src/types/url.d.ts              → declaração do import "?url" (pdf.js)
```

Institucionais OK: about, contact, cookies, disclaimer, privacy, search, terms.
Favicon: `src/app/icon.svg`.

**Bibliotecas instaladas (não reinstalar):** `pdf-lib`, `@cantoo/pdf-lib`, `jszip`, `pdfjs-dist`, `esbuild` (dev).

---

## 🎨 DESIGN SYSTEM

Cores: `bg-paper`, `bg-deep`, `text-accent`, `text-ink`, `text-paper`
Fontes: `font-display`, `font-mono`

Card: `bg-white border border-ink/10 rounded-xl p-6 shadow-sm`
Pill ativo: `bg-deep text-paper`
Pill inativo: `bg-paper text-ink/60 border border-ink/15 hover:border-accent hover:text-accent`
Input: `border border-ink/15 rounded-lg px-3 py-2.5 font-mono focus:ring-2 focus:ring-accent`
Visor: `bg-deep` + `text-accent text-5xl font-mono`
StatBlock highlight: `bg-accent/10 border-accent/30 text-accent`
Botão ação: `bg-deep text-paper font-mono text-xs tracking-widest px-6 py-3 rounded-lg hover:bg-accent`

**JOGOS — tema escuro neon:** container `bg-deep rounded-xl p-6` (ou gradiente escuro), StatBlock dark (`bg-white/5 border-white/10` + texto paper), botões `bg-accent` para ação e `bg-white/5 border-white/15` para inativos. **O visual de cada jogo DEVE combinar com a capa** (`public/games/xxx.jpg`).

Réguas laranja do header/hero: REMOVIDAS. Não recolocar.

---

## 📐 PADRÃO DE CADA TOOL

- `page.tsx` (Server): metadata + ToolLayout
- `[Nome]Client.tsx` ("use client"), PascalCase
- **6 FAQs** + **4 related da MESMA categoria**
- `howItWorks` em inglês, termina com **Your privacy**
- Canonical: `https://multitoolbox.online/tools/[cat]/[slug]`
- UI em inglês
- Multi-moeda USD/EUR/GBP/BRL quando for dinheiro
- Visor `—` se inválido

**Exceção SEO (só Giveaway Picker):** bloco visível em português + 3 FAQs em PT + keywords PT no metadata. Sem texto escondido.

**percentage-calculator: INLINE, NÃO MEXER. Sem Client.**

---

## 🎮 PADRÃO DE CADA JOGO (regras de fábrica — NUNCA pular)

1. **Visual premium igual à CAPA** (tema escuro/neon conforme a capa do jogo).
2. **Sons via Web Audio API** (classe `Sound` local, sem arquivos) — sempre com botão 🔊/🔇.
3. **Controles TECLADO + TOUCH** (botões touch `sm:hidden` e/ou swipe/drag) — NUNCA só teclado.
4. **Curva de dificuldade REAL** (fases/velocidade/IA progressiva — sem teto baixo; "jogo bobo" não).
5. **Sessão mantida** (sessionStorage para nível/recorde — sobrevive a refresh, zera ao fechar) quando fizer sentido.
6. **Testar a lógica ANTES de entregar** (bateria de testes simulando situações-limite).
7. **Evitar re-render 60fps** (setState só quando o valor muda — ex.: placar).
8. **Nada de pixel art manual** a menos que o usuário peça explicitamente (aprendizado: sprites 16×16 ficaram ruins).

---

## 🐛 LIÇÕES APRENDIDAS / CORREÇÕES QUE NÃO PODEM VOLTAR

### Bugs corrigidos (histórico — não repetir)

1. **`tools.ts` NUNCA por insert cirúrgico no usuário** — sempre arquivo INTEIRO (o usuário quebrou o catálogo 1× duplicando Currency).
2. **PDF Compress (pdf.js) — DOMMatrix no SSR:** o pdf.js NÃO pode ser importado estaticamente (usa APIs de navegador). Usar **import dinâmico** (`async function getPdfJs() { const pdfjsLib = await import("pdfjs-dist"); ... workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString(); }`). O import `?url` quebrou no Next 16 — usar `new URL(..., import.meta.url)`.
3. **`setKeywords` do pdf-lib espera ARRAY** (não string) — split por vírgula. `getKeywords()` retorna string.
4. **PDF Protect:** o `pdf-lib` NORMAL não criptografa de verdade — usar **`@cantoo/pdf-lib`** com `doc.encrypt({userPassword, ownerPassword, permissions})` + self-check (reload com senha antes de baixar).
5. **PDFs com senha:** detectar via scan `/Encrypt` no binário (ArrayBuffer) + try/catch por arquivo no merge.
6. **Erro de declaração `draw before initialization`** (Snake Puzzle): funções de desenho devem ser **nível de módulo** (fora do componente) ou declaradas ANTES de quem as usa. Nunca `const draw` depois de `useCallback` que a referencia.
7. **Hydration error (Math.random no estado):** jogos não podem inicializar estado com `Math.random()` no servidor — deck começa vazio e é construído no `useEffect` (client-only).
8. **Block Stacker:** som de tick a cada queda automática era insuportável — usar flag `silent` na queda automática; som só em ações do jogador. MiniPreview deve ser componente de módulo (remontava a cada render).
9. **Noughts & Crosses travava vs computador:** useEffect de IA criava loop de dependência — usar **`setTimeout` simples + refs** (boardRef, modeRef, diffRef) e disparar uma vez.
10. **Minimax do Noughts & Crosses:** `bestMove` NÃO deve negar o resultado do minimax (ele já retorna na perspectiva do jogador). Validado: IA nunca perde em 200 partidas.
11. **Word Guess: lista de palavras** — só palavras de 5 letras (o regex pegou "ENTER" do teclado e "TENDR" inválida). Validar: 736 palavras, todas 5 letras, únicas.
12. **Four in a Row:** IA com minimax + heurística (janelas de 4), prioridade: vencer → bloquear → minimax. Testado (vence/bloqueia).
13. **Snake Puzzle:** fases impossíveis (cabeça-a-cabeça, mesma linha de saída, ciclos, auto-trava) — **verificador de solvabilidade por DFS** no gerador (rejeita e regenera; fallback garantido). Validado: 300 níveis 100% solváveis por brute-force independente. **PENDÊNCIA registrada:** teto de 10 cobras (dificuldade estaciona ~nível 18) — aumentar para ~16-18 cobras + tabuleiro maior quando o usuário pedir.
14. **Desenho de jogo com canvas:** funções `draw` puras e simples; evitar `setState` dentro do loop a cada frame.
15. **ZIP com `jszip`:** `generateAsync({ type: "blob" })` para download; nomes `page-001.pdf` etc.
16. **`Blob([bytes as unknown as BlobPart])`** para compat TS com Uint8Array do pdf-lib.
17. **Página 404 ao publicar:** se o VS Code estiver aberto com o arquivo antigo, a extração não sobrescreve — SEMPRE: (a) baixar o zip de novo (o Downloads não se atualiza sozinho!), (b) fechar o VS Code antes de extrair, (c) conferir o push no terminal ("master -> master" = subiu).

### Regras de comunicação com o usuário (iniciante)

- **1 tool/jogo por mensagem ou em LOTES** (o usuário aprovou lotes: 3 jogos por zip = 1 extração + 1 publish). NUNCA 10 tools numa mensagem.
- **Comandos SEMPRE no formato:** instalação (se houver) → `Expand-Archive -Path "$env:USERPROFILE\Downloads\ARQUIVO.zip" -DestinationPath "C:\multitool" -Force` → teste localhost → publish jeito B (`git add .; git commit -m "..."; git push`).
- **Avisar quando "zip atualizado"** — o usuário precisa baixar de novo.
- Sem opções A/B. Caminho completo de pastas. Avisar limite de chat.
- O usuário é iniciante — explicar erros de terminal com calma (ex.: `/` não separa comandos no PowerShell).

---

## ✅ 59 TOOLS/JOGOS READY — NÃO APAGAR / NÃO RECRIAR DO ZERO

### Tools (46)

| # | Cat | Nome | Slug |
|---|---|---|---|
| 1 | Finance | Percentage Calculator | percentage-calculator **NÃO MEXER** |
| 2 | Finance | Loan / EMI | loan-calculator |
| 3 | Finance | Discount | discount-calculator |
| 4 | Finance | Tip | tip-calculator |
| 5 | Finance | Compound Interest | compound-interest |
| 6 | Finance | VAT / Sales Tax | vat-calculator |
| 7 | Health | BMI | bmi-calculator |
| 8 | Health | Age | age-calculator |
| 9 | Math | Percentage Increase/Decrease | percentage-change |
| 10 | Converters | Unit Converter | unit-converter |
| 11 | Converters | Temperature | temperature-converter |
| 12 | Converters | Currency Converter | currency-converter |
| 13 | Date & Time | Days Until Date | days-until-date |
| 14 | Text | Word Counter | word-counter |
| 15 | Developer | JSON Formatter | json-formatter |
| 16 | Developer | Regex Tester | regex-tester |
| 17 | Developer | JWT Decoder | jwt-decoder |
| 18 | Developer | CSV ⇄ JSON | csv-json-converter |
| 19 | Generators | Password Generator | password-generator |
| 20 | Generators | QR Code Generator | qr-code-generator |
| 21 | Generators | Giveaway Picker / Sorteador | giveaway-picker (SEO PT) |
| 22 | AI | Prompt Generator | prompt-generator |
| 23 | AI | Token Counter | token-counter |
| 24 | AI | API Cost Calculator | ai-cost-calculator |
| 25 | AI | Coding Tools Comparison | ai-coding-tools |
| 26 | AI | Free AI Directory | free-ai-directory |
| 27 | AI | LLM Model Comparison | llm-model-comparison |
| 28 | AI | System Prompt Builder | system-prompt-builder |
| 29 | Math | Scientific Calculator | scientific-calculator |
| 30 | Text | Readability Checker | readability-checker |
| 31 | Images | Image Compressor / Resizer | image-compressor |
| 32 | Images | JPG / PNG / WebP Converter | jpg-png-webp-converter |
| 33 | Images | Image to Base64 | image-to-base64 |
| 34 | PDF | PDF Merge | pdf-merge |
| 35 | PDF | PDF Split / Extract Pages | pdf-split |
| 36 | PDF | Images to PDF | images-to-pdf |
| 37 | PDF | PDF Protect (Password) | pdf-protect (@cantoo/pdf-lib) |
| 38 | PDF | PDF Rotate | pdf-rotate |
| 39 | PDF | PDF Sign | pdf-sign |
| 40 | PDF | PDF Unlock | pdf-unlock |
| 41 | PDF | PDF Compress | pdf-compress (pdf.js dinâmico) |
| 42 | PDF | PDF Watermark | pdf-watermark |
| 43 | PDF | PDF Reorder / Remove Pages | pdf-reorder |
| 44 | PDF | Add Page Numbers to PDF | pdf-number-pages |
| 45 | PDF | PDF Metadata Editor | pdf-metadata |
| 46 | Text | Keyword Density Checker | keyword-density (coming-soon no tools.ts? — VERIFICAR: estava SOON) |

**IMPORTANTE:** conferir o tools.ts atual — o `keyword-density` pode estar `coming-soon` ainda (a tool não foi implementada). Se estiver SOON, mantém SOON.

### Jogos (13) — categoria `games` com campo `image` no catálogo

| # | Jogo | Slug | Visual | Extras |
|---|---|---|---|---|
| 47 | Snake | snake | neon premium, fundo animado, olhos | som, best, teclado+swipe+D-pad |
| 48 | 2048 | 2048 | moderno limpo | som, best, teclado+swipe |
| 49 | Memory Match | memory-match | mesa madeira + emojis grandes | sons (flip/acerto/erro/vitória), 3 níveis, best tempo |
| 50 | Snake Puzzle | snake-puzzle | lavanda claro + cobras curvas | fases infinitas, sessão, UNDO, solvabilidade garantida, som |
| 51 | Noughts & Crosses | noughts-crosses | neon escuro | IA minimax (Hard invencível), 2P, placar |
| 52 | Sequence Memory | sequence-memory | botões redondos arcade neon + orbs animados | **sequência ACUMULATIVA** (original), níveis infinitos |
| 53 | Minesweeper | minesweeper | neon verde escuro | 3 dificuldades, primeiro clique seguro, flag (clique direito/long-press), best tempo |
| 54 | Block Stacker | block-stacker | neon escuro | 7 peças, NEXT+HOLD, ghost, speed até teto, **controles touch** |
| 55 | Dino Run | dino-run | deserto quente escuro | velocidade sem limite, dia/noite, pulo+duck, touch |
| 56 | Word Guess | word-guess | neon escuro | **736 palavras 5 letras**, teclado físico+virtual, stats sessão |
| 57 | Pixel Pong | pixel-pong | neon retrô | IA 3 dificuldades, primeira a 7, mouse/teclas/touch |
| 58 | Brick Breaker | brick-breaker | neon colorido | 10 níveis, power-ups, 3 vidas |
| 59 | Four in a Row | four-in-a-row | neon escuro | IA minimax 3 níveis, 2P, placar |

**Capas em `public/games/`:** snake.jpg, 2048.jpg, memory-match.jpg, snake-puzzle.jpg, noughts-crosses.jpg, sequence-memory.jpg, minesweeper.jpg, block-stacker.jpg, dino-run.jpg, word-guess.jpg, pixel-pong.jpg, brick-breaker.jpg, four-in-a-row.jpg.

**Página da categoria `games` (src/app/tools/games/page.tsx):** usa `tool.image` para exibir capa + badge PLAY/SOON. Não quebrar.

---

## ⏳ COMING-SOON (no tools.ts)

- Finance: salary-calculator
- Health: pregnancy-due-date, calorie-calculator, ideal-weight
- Math: fraction-calculator, gpa-calculator, ratio-calculator, geometry-calculator
- Converters: timezone-converter, number-base-converter, roman-numeral-converter
- Date: date-calculator, countdown-timer, work-days-calculator, unix-timestamp
- Text: text-case-converter, lorem-ipsum-generator, text-diff, slug-generator
- Dev: base64-encoder, url-encoder, uuid-generator, hash-generator
- Generators: random-number-generator, color-palette, dice-roller
- Text: keyword-density (se ainda SOON)

**Nenhum coming-soon de Games resta** (13/13 prontos).

---

## 🎯 FILA (quando voltar)

1. **Keyword Density** (se ainda SOON — placeholder já existe)
2. Typing test / WPM
3. Password strength
4. px → rem
5. Cron generator
6. Color contrast WCAG
7. Depois: esvaziar coming-soon (salary, fraction, gpa, ratio, geometry, timezone, number-base, roman, date, countdown, work-days, unix, case, lorem, diff, slug, base64, url, uuid, hash, random, color, dice)
8. **PENDÊNCIA Snake Puzzle:** subir teto de cobras (16-18) + tabuleiro maior (quando o usuário pedir)

**Extra viável:** formatadores SQL/XML/YAML, minifiers, meta/robots/sitemap, pomodoro, invoice print, inflação, pace/sono, roleta, PDF merge/split (feito), RAG chunk, templates commit/README, mais jogos.

**Não fazer:** PDF→Word, remover fundo IA, grammar/plagiarism/translate, chatbot com API, detector de IA, Whisper, speedtest, WHOIS/DNS/SSL, DA/backlinks, encurtador, hospedar arquivo, downloader YouTube, vídeo pesado. **Nomes de marcas registradas como título** (Tetris→Block Stacker, Wordle→Word Guess, Simon→Sequence Memory, Connect 4→Four in a Row, Breakout→Brick Breaker, Pong→Pixel Pong, Pac-Man→evitar; menção "inspired by" OK no texto).

---

## 📈 ANALYTICS (18/08/2026)

- 496 views · 46 usuários · **10,78 págs/usuário** (excelente) · **2min50s médio** (excelente)
- PDF Tools: 7min33s (provável = usuário testando)
- Tráfego ainda é de lançamento (maioria = dono testando) — **normal para 5 dias**
- AdSense: **aguardar ~30 dias** (indexação + tráfego orgânico primeiro)
- Indexação: Search Console mostrou "Discovered, currently not indexed" (57 URLs) — normal; pedir indexação manual 1×/dia das páginas novas
- Sinal de sucesso futuro: linha do gráfico sobe mesmo sem publicar + usuários via Google (não Direct)

---

## ⚠️ REGRAS

1. Sem A/B.
2. `tools.ts` sempre completo — incluir giveaway-picker E os 13 jogos com `image`.
3. Não recriar tools READY.
4. percentage-calculator não mexer.
5. Não religar PWA install.
6. Não remover TXT Search Console.
7. Textos das tools em EN, exceto a seção PT do Giveaway Picker.
8. 6 FAQs + 4 related.
9. Avisar limite de chat.
10. **Visual dos jogos = igual à capa** (tema escuro/neon).
11. **Todo jogo: som + touch + dificuldade real + testes.**
12. **Comandos no formato jeito B** (`;` separando) e zip SEMPRE baixado de novo + VS Code fechado.

---

## 📍 ONDE PARAMOS (18/08/2026)

- **59 ready** (46 tools + 13 jogos) · 11 categorias + Games = 12 no header
- Categoria **Games 100% completa** (13/13) · PDF 11/11 · Images 3/3 · AI 8/8
- Última publicação: "Add Pixel Pong, Brick Breaker and Four in a Row games"
- **Próximo passo:** Keyword Density (se SOON) → depois fila acima. E **atualizar este prompt master** quando a conversa encher.

## 🧾 CHECKLIST DE NOVA TOOL/JOGO

- [ ] page + Client no padrão (jogo: tema da capa + som + touch + dificuldade)
- [ ] tools.ts completo com histórico READY intacto + giveaway-picker + jogos
- [ ] Testes de lógica antes de entregar
- [ ] zip com caminhos completos; instruir baixar de novo + fechar VS Code
- [ ] localhost OK
- [ ] publish jeito B + confirmar URL live
