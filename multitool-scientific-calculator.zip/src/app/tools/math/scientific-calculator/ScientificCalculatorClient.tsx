"use client";

import { useCallback, useEffect, useState } from "react";

type AngleMode = "deg" | "rad";

interface HistoryEntry {
  expr: string;
  result: string;
}

function toRad(value: number, mode: AngleMode): number {
  return mode === "deg" ? (value * Math.PI) / 180 : value;
}

function formatResult(value: number): string {
  if (!Number.isFinite(value)) return "Error";
  if (Object.is(value, -0)) return "0";
  if (Number.isInteger(value) && Math.abs(value) < 1e15) {
    return value.toLocaleString("en-US");
  }
  if (Math.abs(value) >= 1e15 || (Math.abs(value) < 1e-9 && value !== 0)) {
    return value.toExponential(8).replace(/(\.\d*?)0+e/, "$1e");
  }
  let s = value.toPrecision(12);
  if (s.includes(".")) s = s.replace(/0+$/, "").replace(/\.$/, "");
  return s;
}

export default function ScientificCalculatorClient() {
  const [expr, setExpr] = useState("");
  const [result, setResult] = useState("");
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [mode, setMode] = useState<AngleMode>("deg");
  const [error, setError] = useState<string | null>(null);

  const MAX_LEN = 60;

  const append = useCallback(
    (token: string) => {
      setExpr((current) => {
        if (current.length >= MAX_LEN) return current;
        if (token === "." && /(^|[^0-9])$/.test(current)) {
          return current + "0.";
        }
        if (/[+\-×÷^]/.test(token) && /[+\-×÷^]$/.test(current)) {
          return current.slice(0, -1) + token;
        }
        if (token === "(" && /[0-9)]$/.test(current)) {
          return current + "×(";
        }
        if (/[0-9(]/.test(token) && current.endsWith(")")) {
          return current + "×" + token;
        }
        return current + token;
      });
      setError(null);
    },
    []
  );

  const evaluate = useCallback(
    (source: string): number => {
      const s = source.replace(/×/g, "*").replace(/÷/g, "/");
      // tokenize: numbers (incl. scientific notation), operators, parens, names
      const tokens = s.match(
        /(?:\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?|[+\-*/^()]|[a-zA-Z]+)/g
      ) ?? [];
      if (tokens.length === 0) throw new Error("Empty expression");

      let pos = 0;
      const peek = () => tokens[pos];
      const next = () => tokens[pos++];

      const parseExpr = (): number => {
        let value = parseTerm();
        while (peek() === "+" || peek() === "-") {
          const op = next();
          const rhs = parseTerm();
          value = op === "+" ? value + rhs : value - rhs;
        }
        return value;
      };

      const parseTerm = (): number => {
        let value = parseFactor();
        while (
          peek() === "*" ||
          peek() === "/" ||
          (peek() !== undefined &&
            (peek() === "(" || /^[0-9.]/.test(peek()) || /^[a-zA-Z]/.test(peek())))
        ) {
          if (peek() === "*" || peek() === "/") {
            const op = next();
            const rhs = parseFactor();
            value = op === "*" ? value * rhs : value / rhs;
          } else {
            // implicit multiplication: 2pi = 2×π, 2(3) = 6
            value *= parseFactor();
          }
        }
        return value;
      };

      const parseFactor = (): number => {
        const base = parseUnary();
        if (peek() === "^") {
          next();
          // right-associative: 2^3^2 = 2^(3^2) = 512
          return Math.pow(base, parseFactor());
        }
        return base;
      };

      const parseUnary = (): number => {
        if (peek() === "-") {
          next();
          return -parseUnary();
        }
        if (peek() === "+") {
          next();
          return parseUnary();
        }
        return parsePrimary();
      };

      const parsePrimary = (): number => {
        const token = peek();
        if (token === undefined) throw new Error("Unexpected end");
        if (token === "(") {
          next();
          const v = parseExpr();
          if (next() !== ")") throw new Error("Missing closing parenthesis");
          return v;
        }
        if (/^[0-9.]/.test(token)) {
          next();
          const v = Number(token);
          if (Number.isNaN(v)) throw new Error(`Invalid number: ${token}`);
          return v;
        }
        // function or constant name
        next();
        switch (token) {
          case "pi":
          case "π":
            return Math.PI;
          case "e":
            return Math.E;
          case "sin":
            return Math.sin(toRad(parsePrimary(), mode));
          case "cos":
            return Math.cos(toRad(parsePrimary(), mode));
          case "tan":
            return Math.tan(toRad(parsePrimary(), mode));
          case "asin":
            return (180 / Math.PI) * Math.asin(parsePrimary());
          case "acos":
            return (180 / Math.PI) * Math.acos(parsePrimary());
          case "atan":
            return (180 / Math.PI) * Math.atan(parsePrimary());
          case "ln":
            return Math.log(parsePrimary());
          case "log":
            return Math.log10(parsePrimary());
          case "sqrt":
            return Math.sqrt(parsePrimary());
          case "cbrt":
            return Math.cbrt(parsePrimary());
          default:
            throw new Error(`Unknown: ${token}`);
        }
      };

      const value = parseExpr();
      if (pos !== tokens.length) throw new Error(`Unexpected: ${tokens[pos]}`);
      if (!Number.isFinite(value)) throw new Error("Math error (division by zero?)");
      return value;
    },
    [mode]
  );

  const calculate = useCallback(() => {
    if (!expr.trim()) return;
    try {
      const value = evaluate(expr);
      const formatted = formatResult(value);
      setResult(formatted);
      setHistory((h) => [...h, { expr, result: formatted }].slice(-20));
      setExpr(formatted);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Invalid expression");
    }
  }, [expr, evaluate]);

  const clear = useCallback(() => {
    setExpr("");
    setResult("");
    setError(null);
  }, []);

  const backspace = useCallback(() => {
    setExpr((current) => current.slice(0, -1));
  }, []);

  const clearHistory = () => setHistory([]);

  const fn = (name: string, label: string) => (
    <button
      key={name}
      type="button"
      onClick={() => append(name + "(")}
      className="bg-paper text-ink/80 border border-ink/15 rounded-lg py-3 font-mono text-xs font-semibold hover:border-accent hover:text-accent transition-colors"
    >
      {label}
    </button>
  );

  const keyBtn = (label: string, token: string, cls = "") => (
    <button
      key={label}
      type="button"
      onClick={() => append(token)}
      className={`rounded-lg py-3 font-mono text-sm font-semibold transition-colors ${cls}`}
    >
      {label}
    </button>
  );

  // keyboard support
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        e.preventDefault();
        calculate();
        return;
      }
      if (e.key === "Backspace") {
        backspace();
        return;
      }
      if (e.key === "Escape") {
        clear();
        return;
      }
      if (/^[0-9.+\-*/^()]$/.test(e.key)) {
        const map: Record<string, string> = { "*": "×", "/": "÷" };
        append(map[e.key] ?? e.key);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [append, calculate, backspace, clear]);

  return (
    <div className="bg-white border border-ink/10 rounded-xl p-6 flex flex-col gap-4 shadow-sm">
      {/* Display */}
      <div className="bg-deep rounded-lg px-5 py-4">
        <span className="font-mono text-xs text-paper/50 tracking-widest block mb-2">
          {mode === "deg" ? "DEG" : "RAD"} — SCIENTIFIC
        </span>
        <div className="min-h-[3.5rem]">
          <p className="font-mono text-sm text-paper/60 break-all leading-snug">
            {expr || "\u00A0"}
          </p>
          <p className="font-mono text-3xl font-semibold text-accent break-all leading-tight">
            {result || "0"}
          </p>
        </div>
        {error && (
          <p className="font-mono text-xs text-accent mt-1">{error}</p>
        )}
      </div>

      {/* Mode + clear row */}
      <div className="flex gap-2 flex-wrap">
        <button
          type="button"
          onClick={() => setMode((m) => (m === "deg" ? "rad" : "deg"))}
          className={`font-mono text-xs tracking-widest px-4 py-2 rounded-full transition-colors ${
            mode === "deg"
              ? "bg-deep text-paper"
              : "bg-paper text-ink/60 border border-ink/15 hover:border-accent hover:text-accent"
          }`}
        >
          DEG
        </button>
        <button
          type="button"
          onClick={() => setMode((m) => (m === "rad" ? "deg" : "rad"))}
          className={`font-mono text-xs tracking-widest px-4 py-2 rounded-full transition-colors ${
            mode === "rad"
              ? "bg-deep text-paper"
              : "bg-paper text-ink/60 border border-ink/15 hover:border-accent hover:text-accent"
          }`}
        >
          RAD
        </button>
        <button
          type="button"
          onClick={clear}
          className="font-mono text-xs tracking-widest px-4 py-2 rounded-full bg-paper text-ink/60 border border-ink/15 hover:border-accent hover:text-accent transition-colors"
        >
          AC
        </button>
        <button
          type="button"
          onClick={backspace}
          className="font-mono text-xs tracking-widest px-4 py-2 rounded-full bg-paper text-ink/60 border border-ink/15 hover:border-accent hover:text-accent transition-colors"
        >
          ⌫
        </button>
      </div>

      {/* Scientific row */}
      <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
        {fn("sin", "sin")}
        {fn("cos", "cos")}
        {fn("tan", "tan")}
        {fn("ln", "ln")}
        {fn("log", "log")}
        {fn("sqrt", "√")}
        {fn("cbrt", "∛")}
        {fn("asin", "asin")}
        {fn("acos", "acos")}
        {fn("atan", "atan")}
        <button
          type="button"
          onClick={() => append("pi")}
          className="bg-paper text-ink/80 border border-ink/15 rounded-lg py-3 font-mono text-xs font-semibold hover:border-accent hover:text-accent transition-colors"
        >
          π
        </button>
        <button
          type="button"
          onClick={() => append("e")}
          className="bg-paper text-ink/80 border border-ink/15 rounded-lg py-3 font-mono text-xs font-semibold hover:border-accent hover:text-accent transition-colors"
        >
          e
        </button>
        <button
          type="button"
          onClick={() => append("^")}
          className="bg-paper text-ink/80 border border-ink/15 rounded-lg py-3 font-mono text-xs font-semibold hover:border-accent hover:text-accent transition-colors"
        >
          xʸ
        </button>
        <button
          type="button"
          onClick={() => append("(1/(")}
          className="bg-paper text-ink/80 border border-ink/15 rounded-lg py-3 font-mono text-xs font-semibold hover:border-accent hover:text-accent transition-colors"
        >
          1/x
        </button>
      </div>

      {/* Keypad */}
      <div className="grid grid-cols-4 gap-2">
        {keyBtn("7", "7", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("8", "8", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("9", "9", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("÷", "÷", "bg-deep text-paper hover:bg-accent")}
        {keyBtn("4", "4", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("5", "5", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("6", "6", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("×", "×", "bg-deep text-paper hover:bg-accent")}
        {keyBtn("1", "1", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("2", "2", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("3", "3", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("−", "-", "bg-deep text-paper hover:bg-accent")}
        {keyBtn("0", "0", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn(".", ".", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("(", "(", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("+", "+", "bg-deep text-paper hover:bg-accent")}
        {keyBtn(")", ")", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        {keyBtn("x²", "^2", "bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent")}
        <button
          type="button"
          onClick={clear}
          className="rounded-lg py-3 font-mono text-sm font-semibold bg-paper text-ink border border-ink/15 hover:border-accent hover:text-accent transition-colors"
        >
          C
        </button>
        <button
          type="button"
          onClick={calculate}
          className="rounded-lg py-3 font-mono text-sm font-semibold bg-accent text-paper hover:opacity-90 transition-colors"
        >
          =
        </button>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs tracking-widest text-ink/60">
              HISTORY
            </span>
            <button
              type="button"
              onClick={clearHistory}
              className="font-mono text-[10px] tracking-widest px-3 py-1.5 rounded-full bg-paper text-ink/60 border border-ink/15 hover:border-accent hover:text-accent transition-colors"
            >
              CLEAR
            </button>
          </div>
          <div className="bg-paper border border-ink/10 rounded-lg divide-y divide-ink/5">
            {[...history].reverse().map((h, i) => (
              <button
                key={`${h.expr}-${i}`}
                type="button"
                onClick={() => setExpr(h.expr)}
                className="w-full flex items-baseline justify-between gap-3 px-4 py-2 text-left hover:bg-ink/5 transition-colors"
              >
                <span className="font-mono text-xs text-ink/50 break-all">
                  {h.expr}
                </span>
                <span className="font-mono text-sm font-semibold text-accent whitespace-nowrap">
                  = {h.result}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="bg-paper border border-ink/10 rounded-lg px-4 py-3 text-sm text-ink/70">
        <strong className="text-ink">Note:</strong> Keyboard supported —
        Enter calculates, Backspace deletes, Escape clears. Trigonometry
        follows the DEG/RAD toggle. Results are rounded to 12 significant
        digits.
      </div>
    </div>
  );
}
